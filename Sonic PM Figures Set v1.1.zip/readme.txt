☀◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆☀

Hello dear reader! This is Hi-Core King, chief designer and main creator of the Sonic Protamedra project. Thank you for downloading this piece of content! If you paid for this content or downloaded it from somewhere other than Xaosphora's official GitHub page, then please report the event immediately to dsdcreate@gmail.com! Also if you are wondering how to pronounce the name of the Island that this project is named after, it is pronounced as following: Pro•ta•med•dra

I hope you enjoy the content and if you find any typos, mistakes, or encounter any bugs please let the team know at the email provided above! :)

☀◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆☀